// Created by iWeb 2.0.4 local-build-20081108

setTransparentGifURL('../../../../Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({shadow_1:new IWShadow({blurRadius:3,offset:new IWPoint(0.0000,0.0000),color:'#463c3c',opacity:1.000000}),shadow_0:new IWShadow({blurRadius:4,offset:new IWPoint(0.0000,0.0000),color:'#463c3c',opacity:0.600000})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{dynamicallyPopulate();loadMozillaCSS('8_Dan_gets_schooled_files/8_Dan_gets_schooledMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');fixAllIEPNGs('../../../../Media/transparent.gif');Widget.onload();fixupIECSS3Opacity('id2');IMpreload('8_Dan_gets_schooled_files','shapeimage_4','0');IMpreload('8_Dan_gets_schooled_files','shapeimage_5','0');applyEffects()}
function onPageUnload()
{Widget.onunload();}
